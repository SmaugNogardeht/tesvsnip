namespace TESVSnip {
    partial class HeaderEditor {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if(disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HeaderEditor));
            this.cb0 = new System.Windows.Forms.CheckBox();
            this.cb1 = new System.Windows.Forms.CheckBox();
            this.cb3 = new System.Windows.Forms.CheckBox();
            this.cb2 = new System.Windows.Forms.CheckBox();
            this.cb5 = new System.Windows.Forms.CheckBox();
            this.cb4 = new System.Windows.Forms.CheckBox();
            this.cb7 = new System.Windows.Forms.CheckBox();
            this.cb6 = new System.Windows.Forms.CheckBox();
            this.cb9 = new System.Windows.Forms.CheckBox();
            this.cb8 = new System.Windows.Forms.CheckBox();
            this.cb11 = new System.Windows.Forms.CheckBox();
            this.cb10 = new System.Windows.Forms.CheckBox();
            this.cb13 = new System.Windows.Forms.CheckBox();
            this.cb12 = new System.Windows.Forms.CheckBox();
            this.cb15 = new System.Windows.Forms.CheckBox();
            this.cb14 = new System.Windows.Forms.CheckBox();
            this.cb31 = new System.Windows.Forms.CheckBox();
            this.cb30 = new System.Windows.Forms.CheckBox();
            this.cb29 = new System.Windows.Forms.CheckBox();
            this.cb28 = new System.Windows.Forms.CheckBox();
            this.cb27 = new System.Windows.Forms.CheckBox();
            this.cb26 = new System.Windows.Forms.CheckBox();
            this.cb25 = new System.Windows.Forms.CheckBox();
            this.cb24 = new System.Windows.Forms.CheckBox();
            this.cb23 = new System.Windows.Forms.CheckBox();
            this.cb22 = new System.Windows.Forms.CheckBox();
            this.cb21 = new System.Windows.Forms.CheckBox();
            this.cb20 = new System.Windows.Forms.CheckBox();
            this.cb19 = new System.Windows.Forms.CheckBox();
            this.cb18 = new System.Windows.Forms.CheckBox();
            this.cb17 = new System.Windows.Forms.CheckBox();
            this.cb16 = new System.Windows.Forms.CheckBox();
            this.bCancel = new System.Windows.Forms.Button();
            this.bSave = new System.Windows.Forms.Button();
            this.tbFormID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tbFlags2 = new System.Windows.Forms.TextBox();
            this.tbFlags3 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tbName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cb0
            // 
            resources.ApplyResources(this.cb0, "cb0");
            this.cb0.Name = "cb0";
            this.cb0.Tag = "0";
            this.cb0.UseVisualStyleBackColor = true;
            // 
            // cb1
            // 
            resources.ApplyResources(this.cb1, "cb1");
            this.cb1.Name = "cb1";
            this.cb1.Tag = "1";
            this.cb1.UseVisualStyleBackColor = true;
            // 
            // cb3
            // 
            resources.ApplyResources(this.cb3, "cb3");
            this.cb3.Name = "cb3";
            this.cb3.Tag = "3";
            this.cb3.UseVisualStyleBackColor = true;
            // 
            // cb2
            // 
            resources.ApplyResources(this.cb2, "cb2");
            this.cb2.Name = "cb2";
            this.cb2.Tag = "2";
            this.cb2.UseVisualStyleBackColor = true;
            // 
            // cb5
            // 
            resources.ApplyResources(this.cb5, "cb5");
            this.cb5.Name = "cb5";
            this.cb5.Tag = "5";
            this.cb5.UseVisualStyleBackColor = true;
            // 
            // cb4
            // 
            resources.ApplyResources(this.cb4, "cb4");
            this.cb4.Name = "cb4";
            this.cb4.Tag = "4";
            this.cb4.UseVisualStyleBackColor = true;
            // 
            // cb7
            // 
            resources.ApplyResources(this.cb7, "cb7");
            this.cb7.Name = "cb7";
            this.cb7.Tag = "7";
            this.cb7.UseVisualStyleBackColor = true;
            // 
            // cb6
            // 
            resources.ApplyResources(this.cb6, "cb6");
            this.cb6.Name = "cb6";
            this.cb6.Tag = "6";
            this.cb6.UseVisualStyleBackColor = true;
            // 
            // cb9
            // 
            resources.ApplyResources(this.cb9, "cb9");
            this.cb9.Name = "cb9";
            this.cb9.Tag = "9";
            this.cb9.UseVisualStyleBackColor = true;
            // 
            // cb8
            // 
            resources.ApplyResources(this.cb8, "cb8");
            this.cb8.Name = "cb8";
            this.cb8.Tag = "8";
            this.cb8.UseVisualStyleBackColor = true;
            // 
            // cb11
            // 
            resources.ApplyResources(this.cb11, "cb11");
            this.cb11.Name = "cb11";
            this.cb11.Tag = "11";
            this.cb11.UseVisualStyleBackColor = true;
            // 
            // cb10
            // 
            resources.ApplyResources(this.cb10, "cb10");
            this.cb10.Name = "cb10";
            this.cb10.Tag = "10";
            this.cb10.UseVisualStyleBackColor = true;
            // 
            // cb13
            // 
            resources.ApplyResources(this.cb13, "cb13");
            this.cb13.Name = "cb13";
            this.cb13.Tag = "13";
            this.cb13.UseVisualStyleBackColor = true;
            // 
            // cb12
            // 
            resources.ApplyResources(this.cb12, "cb12");
            this.cb12.Name = "cb12";
            this.cb12.Tag = "12";
            this.cb12.UseVisualStyleBackColor = true;
            // 
            // cb15
            // 
            resources.ApplyResources(this.cb15, "cb15");
            this.cb15.Name = "cb15";
            this.cb15.Tag = "15";
            this.cb15.UseVisualStyleBackColor = true;
            // 
            // cb14
            // 
            resources.ApplyResources(this.cb14, "cb14");
            this.cb14.Name = "cb14";
            this.cb14.Tag = "14";
            this.cb14.UseVisualStyleBackColor = true;
            // 
            // cb31
            // 
            resources.ApplyResources(this.cb31, "cb31");
            this.cb31.Name = "cb31";
            this.cb31.Tag = "31";
            this.cb31.UseVisualStyleBackColor = true;
            // 
            // cb30
            // 
            resources.ApplyResources(this.cb30, "cb30");
            this.cb30.Name = "cb30";
            this.cb30.Tag = "30";
            this.cb30.UseVisualStyleBackColor = true;
            // 
            // cb29
            // 
            resources.ApplyResources(this.cb29, "cb29");
            this.cb29.Name = "cb29";
            this.cb29.Tag = "29";
            this.cb29.UseVisualStyleBackColor = true;
            // 
            // cb28
            // 
            resources.ApplyResources(this.cb28, "cb28");
            this.cb28.Name = "cb28";
            this.cb28.Tag = "28";
            this.cb28.UseVisualStyleBackColor = true;
            // 
            // cb27
            // 
            resources.ApplyResources(this.cb27, "cb27");
            this.cb27.Name = "cb27";
            this.cb27.Tag = "27";
            this.cb27.UseVisualStyleBackColor = true;
            // 
            // cb26
            // 
            resources.ApplyResources(this.cb26, "cb26");
            this.cb26.Name = "cb26";
            this.cb26.Tag = "26";
            this.cb26.UseVisualStyleBackColor = true;
            // 
            // cb25
            // 
            resources.ApplyResources(this.cb25, "cb25");
            this.cb25.Name = "cb25";
            this.cb25.Tag = "25";
            this.cb25.UseVisualStyleBackColor = true;
            // 
            // cb24
            // 
            resources.ApplyResources(this.cb24, "cb24");
            this.cb24.Name = "cb24";
            this.cb24.Tag = "24";
            this.cb24.UseVisualStyleBackColor = true;
            // 
            // cb23
            // 
            resources.ApplyResources(this.cb23, "cb23");
            this.cb23.Name = "cb23";
            this.cb23.Tag = "23";
            this.cb23.UseVisualStyleBackColor = true;
            // 
            // cb22
            // 
            resources.ApplyResources(this.cb22, "cb22");
            this.cb22.Name = "cb22";
            this.cb22.Tag = "22";
            this.cb22.UseVisualStyleBackColor = true;
            // 
            // cb21
            // 
            resources.ApplyResources(this.cb21, "cb21");
            this.cb21.Name = "cb21";
            this.cb21.Tag = "21";
            this.cb21.UseVisualStyleBackColor = true;
            // 
            // cb20
            // 
            resources.ApplyResources(this.cb20, "cb20");
            this.cb20.Name = "cb20";
            this.cb20.Tag = "20";
            this.cb20.UseVisualStyleBackColor = true;
            // 
            // cb19
            // 
            resources.ApplyResources(this.cb19, "cb19");
            this.cb19.Name = "cb19";
            this.cb19.Tag = "19";
            this.cb19.UseVisualStyleBackColor = true;
            // 
            // cb18
            // 
            resources.ApplyResources(this.cb18, "cb18");
            this.cb18.Name = "cb18";
            this.cb18.Tag = "18";
            this.cb18.UseVisualStyleBackColor = true;
            // 
            // cb17
            // 
            resources.ApplyResources(this.cb17, "cb17");
            this.cb17.Name = "cb17";
            this.cb17.Tag = "17";
            this.cb17.UseVisualStyleBackColor = true;
            // 
            // cb16
            // 
            resources.ApplyResources(this.cb16, "cb16");
            this.cb16.Name = "cb16";
            this.cb16.Tag = "16";
            this.cb16.UseVisualStyleBackColor = true;
            // 
            // bCancel
            // 
            resources.ApplyResources(this.bCancel, "bCancel");
            this.bCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.bCancel.Name = "bCancel";
            this.bCancel.UseVisualStyleBackColor = true;
            this.bCancel.Click += new System.EventHandler(this.bCancel_Click);
            // 
            // bSave
            // 
            resources.ApplyResources(this.bSave, "bSave");
            this.bSave.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.bSave.Name = "bSave";
            this.bSave.UseVisualStyleBackColor = true;
            this.bSave.Click += new System.EventHandler(this.bSave_Click);
            // 
            // tbFormID
            // 
            resources.ApplyResources(this.tbFormID, "tbFormID");
            this.tbFormID.Name = "tbFormID";
            this.tbFormID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.HexOnlyKeyPress);
            this.tbFormID.Leave += new System.EventHandler(this.HexValidCheck);
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // tbFlags2
            // 
            resources.ApplyResources(this.tbFlags2, "tbFlags2");
            this.tbFlags2.Name = "tbFlags2";
            this.tbFlags2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.HexOnlyKeyPress);
            this.tbFlags2.Leave += new System.EventHandler(this.HexValidCheck);
            // 
            // tbFlags3
            // 
            resources.ApplyResources(this.tbFlags3, "tbFlags3");
            this.tbFlags3.Name = "tbFlags3";
            this.tbFlags3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.HexOnlyKeyPress);
            this.tbFlags3.Leave += new System.EventHandler(this.HexValidCheck);
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // tbName
            // 
            resources.ApplyResources(this.tbName, "tbName");
            this.tbName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbName.Name = "tbName";
            this.tbName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbName_KeyPress);
            this.tbName.Leave += new System.EventHandler(this.tbName_Leave);
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            // 
            // HeaderEditor
            // 
            this.AcceptButton = this.bSave;
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.bCancel;
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbName);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbFlags3);
            this.Controls.Add(this.tbFlags2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbFormID);
            this.Controls.Add(this.bSave);
            this.Controls.Add(this.bCancel);
            this.Controls.Add(this.cb31);
            this.Controls.Add(this.cb30);
            this.Controls.Add(this.cb29);
            this.Controls.Add(this.cb28);
            this.Controls.Add(this.cb27);
            this.Controls.Add(this.cb26);
            this.Controls.Add(this.cb25);
            this.Controls.Add(this.cb24);
            this.Controls.Add(this.cb23);
            this.Controls.Add(this.cb22);
            this.Controls.Add(this.cb21);
            this.Controls.Add(this.cb20);
            this.Controls.Add(this.cb19);
            this.Controls.Add(this.cb18);
            this.Controls.Add(this.cb17);
            this.Controls.Add(this.cb16);
            this.Controls.Add(this.cb15);
            this.Controls.Add(this.cb14);
            this.Controls.Add(this.cb13);
            this.Controls.Add(this.cb12);
            this.Controls.Add(this.cb11);
            this.Controls.Add(this.cb10);
            this.Controls.Add(this.cb9);
            this.Controls.Add(this.cb8);
            this.Controls.Add(this.cb7);
            this.Controls.Add(this.cb6);
            this.Controls.Add(this.cb5);
            this.Controls.Add(this.cb4);
            this.Controls.Add(this.cb3);
            this.Controls.Add(this.cb2);
            this.Controls.Add(this.cb1);
            this.Controls.Add(this.cb0);
            this.Name = "HeaderEditor";
            this.ShowInTaskbar = false;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox cb0;
        private System.Windows.Forms.CheckBox cb1;
        private System.Windows.Forms.CheckBox cb3;
        private System.Windows.Forms.CheckBox cb2;
        private System.Windows.Forms.CheckBox cb5;
        private System.Windows.Forms.CheckBox cb4;
        private System.Windows.Forms.CheckBox cb7;
        private System.Windows.Forms.CheckBox cb6;
        private System.Windows.Forms.CheckBox cb9;
        private System.Windows.Forms.CheckBox cb8;
        private System.Windows.Forms.CheckBox cb11;
        private System.Windows.Forms.CheckBox cb10;
        private System.Windows.Forms.CheckBox cb13;
        private System.Windows.Forms.CheckBox cb12;
        private System.Windows.Forms.CheckBox cb15;
        private System.Windows.Forms.CheckBox cb14;
        private System.Windows.Forms.CheckBox cb31;
        private System.Windows.Forms.CheckBox cb30;
        private System.Windows.Forms.CheckBox cb29;
        private System.Windows.Forms.CheckBox cb28;
        private System.Windows.Forms.CheckBox cb27;
        private System.Windows.Forms.CheckBox cb26;
        private System.Windows.Forms.CheckBox cb25;
        private System.Windows.Forms.CheckBox cb24;
        private System.Windows.Forms.CheckBox cb23;
        private System.Windows.Forms.CheckBox cb22;
        private System.Windows.Forms.CheckBox cb21;
        private System.Windows.Forms.CheckBox cb20;
        private System.Windows.Forms.CheckBox cb19;
        private System.Windows.Forms.CheckBox cb18;
        private System.Windows.Forms.CheckBox cb17;
        private System.Windows.Forms.CheckBox cb16;
        private System.Windows.Forms.Button bCancel;
        private System.Windows.Forms.Button bSave;
        private System.Windows.Forms.TextBox tbFormID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbFlags2;
        private System.Windows.Forms.TextBox tbFlags3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbName;
        private System.Windows.Forms.Label label4;
    }
}